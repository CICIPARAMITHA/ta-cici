<nav class="mdl-navigation">
    <a class="mdl-navigation__link mdl-navigation__link--current" href="<?php echo e(url('admin/beranda')); ?>">
        <i class="material-icons" role="presentation">dashboard</i>
        Smart Plant
    </a>

      <a class="mdl-navigation__link mdl-navigation__link--current" href="<?php echo e(url('admin/profil')); ?>">
        <i class="material-icons">developer_board</i>
        Profil
    </a>
   
    <div class="mdl-layout-spacer"></div>
    <hr>
    <a class="mdl-navigation__link" href="https://github.com/CreativeIT/getmdl-dashboard">
        <i class="material-icons" role="presentation">link</i>
        GitHub
    </a>
</nav>
       <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/smart-garden/system/resources/views/admin/template/section/sidebar.blade.php ENDPATH**/ ?>