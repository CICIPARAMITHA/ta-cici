<?php $__env->startSection('content'); ?>
<div class="mdl-grid mdl-grid--no-spacing dashboard">

    <div class="mdl-grid mdl-cell mdl-cell--9-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone mdl-cell--top">

       <!-- Weather widget-->
       <div class="mdl-cell mdl-cell--4-col-desktop mdl-cell--4-col-tablet mdl-cell--2-col-phone">
        <div class="mdl-card mdl-shadow--2dp weather">
            <div class="mdl-card__title">
                <h2 class="mdl-card__title-text">Temperatue</h2>

                <div class="mdl-layout-spacer"></div>
                <div class="mdl-card__subtitle-text">
                    <i class="material-icons">room</i>
                    Minsk, Belarus
                </div>
            </div>
            <div class="mdl-card__supporting-text mdl-card--expand">
                <p class="weather-temperature" id="soil"><?php echo e($nilai->soil); ?> pH</p>

                <p class="weather-description">
                    Cloudy and snow
                </p>
            </div>
        </div>
    </div>
    <!-- Trending widget-->



    <!-- Weather widget-->
    <div class="mdl-cell mdl-cell--4-col-desktop mdl-cell--4-col-tablet mdl-cell--2-col-phone">
        <div class="mdl-card mdl-shadow--2dp weather">
            <div class="mdl-card__title">
                <h2 class="mdl-card__title-text">Temperatue</h2>

                <div class="mdl-layout-spacer"></div>
                <div class="mdl-card__subtitle-text">
                    <i class="material-icons">room</i>
                    Minsk, Belarus
                </div>
            </div>
            <div class="mdl-card__supporting-text mdl-card--expand">
                <p class="weather-temperature" id="temperatur"><?php echo e($nilai->temperatur); ?><sup>&deg;</sup>C</p>

                <p class="weather-description">
                    Cloudy and snow
                </p>
            </div>
        </div>
    </div>
    <!-- Trending widget-->

    <!-- Weather widget-->
    <div class="mdl-cell mdl-cell--4-col-desktop mdl-cell--4-col-tablet mdl-cell--2-col-phone">
        <div class="mdl-card mdl-shadow--2dp weather">
            <div class="mdl-card__title">
                <h2 class="mdl-card__title-text">Kelembaban Ruangan</h2>

                <div class="mdl-layout-spacer"></div>
                <div class="mdl-card__subtitle-text">
                    <i class="material-icons">room</i>
                    Minsk, Belarus
                </div>
            </div>
            <div class="mdl-card__supporting-text mdl-card--expand">
                <p class="weather-temperature" id="humidity"><?php echo e($nilai->humidity); ?> RH</p>

                <p class="weather-description">
                    Cloudy and snow
                </p>
            </div>
        </div>
    </div>
    <!-- Trending widget-->



    <!-- Cotoneaster card-->
    <div class="mdl-cell mdl-cell--5-col-desktop mdl-cell--5-col-tablet mdl-cell--2-col-phone">
        <div class="mdl-card mdl-shadow--2dp cotoneaster">
         <iframe src="http://192.168.113.120">
            Your browser doesn't support iframes
        </iframe>
    </div>
</div>

<div class="mdl-cell mdl-cell--7-col-desktop mdl-cell--7-col-tablet mdl-cell--4-col-phone">
    <div class="mdl-card mdl-shadow--2dp line-chart">
        <div class="mdl-card__title">
            <h2 class="mdl-card__title-text">Suhu Ruangan</h2>
        </div>
        <div class="mdl-card__supporting-text">
            <canvas id="realtime-chart" height="100px"></canvas>

        </div>
    </div>
</div>
</div>

<div class="mdl-cell mdl-cell--5-col-desktop mdl-cell--5-col-tablet mdl-cell--2-col-phone">

</div>
<!-- Table-->


</div>
</div>






<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript">

// KAMAR 1 ===================
    function soil(){
        $('#soil').load("<?php echo e(url('admin/beranda')); ?>" + ' #soil');
    }

    function temperatur(){
        $('#temperatur').load("<?php echo e(url('admin/beranda')); ?>" + ' #temperatur');
    }

    function humidity(){
        $('#humidity').load("<?php echo e(url('admin/beranda')); ?>" + ' #humidity');
    }


    setInterval( ()=>{
        soil();
        temperatur();
        humidity();
    }, 2000);




</script>





<script>
    const ctx = document.getElementById('realtime-chart').getContext('2d');

    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Suhu Ruangan',
                data: [],
                borderWidth: 4,
                borderColor: 'rgba(0, 255, 254)',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
                maintainAspectRatio: false, // Nonaktifkan perbandingan aspek agar dapat mengatur tinggi secara bebas
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 50,
                        ticks: {
                            stepSize: 10
                        }
                    }
                }
            }
        });

    function fetchData() {
        $.ajax({
            url: '<?php echo e(url("load")); ?>',
            type: 'GET',
            success: function(data) {
                var waktu = new Date(data.created_at);
                var jam = waktu.getUTCHours().toString().padStart(2, '0');
                var menit = waktu.getUTCMinutes().toString().padStart(2, '0');
                var detik = waktu.getUTCSeconds().toString().padStart(2, '0');
                chart.data.labels.push(jam + ':' + menit + ':' + detik);
                if (chart.data.labels.length > 12) {
                    chart.data.labels = chart.data.labels.slice(-12);
                }

                    // push data suhu
                chart.data.datasets[0].data.push(data.suhu);
                if (chart.data.datasets[0].data.length > 12) {
                    chart.data.datasets[0].data = chart.data.datasets[0].data.slice(-12);
                }
                chart.update();
            }
        });
    }


        // Memanggil fetchData pertama kali untuk menampilkan data pertama
    fetchData();

    setInterval(fetchData, 5000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/smart-plant/system/resources/views/admin/beranda.blade.php ENDPATH**/ ?>