<?php $__env->startSection('content'); ?>
<main class="mdl-layout__content ui-form-components">

	<div class="mdl-grid mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone mdl-cell--top">

		<div class="mdl-cell mdl-cell--7-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone">
			<div class="mdl-card mdl-shadow--2dp">
				<div class="mdl-card__title">
					<h5 class="mdl-card__title-text text-color--white">Profil Akun</h5>
				</div>
				<div class="mdl-card__supporting-text">
					<div class="form form--basic">
						<div class="mdl-grid">
							<div class="mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone form__article">
								<form action="<?php echo e(url('admin/profil/update')); ?>" method="post">
									<?php echo csrf_field(); ?>
									<h3 class="text-color--smooth-gray">Update Akun</h3>
										<?php $__currentLoopData = ['success', 'warning', 'danger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(session($status)): ?>
									<div class="alert alert-<?php echo e($status); ?> mt-3 alert-dismissable custom-<?php echo e($status); ?>-box">
										<a href="#" class="close" data-dismiss='alert' aria-label='close'></a>
										<strong> <?php echo e(session($status)); ?> </strong>
									</div>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<div class="mdl-textfield mdl-js-textfield full-size">
										<input class="mdl-textfield__input" type="text" required value="<?php echo e($user->username); ?>" name="username" id="first-name">
										<label class="mdl-textfield__label" for="first-name">Username</label>
									</div>

									<div class="mdl-textfield mdl-js-textfield full-size">
										<input class="mdl-textfield__input" type="text" required value="<?php echo e($user->ip); ?>" name="ip" id="first-name">
										<label class="mdl-textfield__label" for="first-name">Ip</label>
									</div>

									<div class="mdl-textfield mdl-js-textfield full-size">
										<input class="mdl-textfield__input" name="new_password" type="password" raquired id="last-name">
										<label class="mdl-textfield__label" for="last-name">Password Baru</label>
									</div>
									<div class="mdl-textfield mdl-js-textfield full-size">
										<input class="mdl-textfield__input" name="konfirmasi" type="password" raquired id="e-mail">
										<label class="mdl-textfield__label" for="e-mail">Konfirmasi Password Baru</label>
									</div>

									<button class="mdl-button mdl-js-button mdl-button--raised color--light-blue">
										UPDATE
									</button>
								</form>
							</div>
						</div>


					</div>
				</div>
			</div>
		</div>

		

	</main>	

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/smart-garden/system/resources/views/admin/profil.blade.php ENDPATH**/ ?>